/**
 * CertificadorPrevisionalSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package ws.cl.gov.fonasa.certificadorprevisional;

public interface CertificadorPrevisionalSoap extends java.rmi.Remote {
    public ws.cl.gov.fonasa.certificadorprevisional.ReplyCertificadorPrevisionalTO getCertificadoPrevisional(ws.cl.gov.fonasa.certificadorprevisional.QueryCertificadorPrevisionalTO query) throws java.rmi.RemoteException;
}
